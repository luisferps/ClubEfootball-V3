# -*- coding: utf-8 -*-
import unittest

from executar_lote_187 import confere_impetos_confirmados
from vaga_impeto import (ESTADO_DESCONHECIDA, ESTADO_LIVRE,
                         ESTADO_SEM_VAGA, normaliza_vaga,
                         pode_publicar_resultado, pode_testar_impeto,
                         separa_fila_por_confirmacao)


class RegraDaVagaTest(unittest.TestCase):
    def test_impeto_conferido_no_jogo_nao_pode_ser_trocado(self):
        arquivo = {"impetos_confirmados": {"cards": {
            "c1": {"boostIds": [10], "nm": [[1, 4]], "nx": [],
                   "nmn": ["Teste +4"]}
        }}}
        correto = {"c1": {"boostId": 10, "boostId2": 0,
                           "nm": [[1, 4]], "nx": [], "nmn": ["Teste +4"]}}
        errado = {"c1": dict(correto["c1"], nm=[[1, 3]])}
        self.assertEqual(confere_impetos_confirmados(correto, arquivo), [])
        self.assertTrue(confere_impetos_confirmados(errado, arquivo))

    def test_salah_sem_vaga_nao_abre_candidato(self):
        card = {"id": "105880691466019", "sl": [0, 1],
                "vaga_estado": "confirmada_sem_vaga", "vaga": [None, None, None]}
        self.assertEqual(normaliza_vaga(card), ESTADO_SEM_VAGA)
        self.assertEqual(card["sl"], [0, 0])
        self.assertFalse(pode_testar_impeto(card))
        self.assertTrue(pode_publicar_resultado(card))

    def test_vaga_marcada_pela_fonte_continua_elegivel(self):
        card = {"vaga": ["NATIVO", "VAGA", None], "sl": [0, 0]}
        self.assertEqual(normaliza_vaga(card), ESTADO_LIVRE)
        self.assertEqual(card["sl"], [0, 1])
        self.assertTrue(pode_testar_impeto(card))
        self.assertTrue(pode_publicar_resultado(card))

    def test_resposta_nao_confirmada_falha_fechada(self):
        card = {"boostId": 0, "boostId2": 0, "sl": [0, 1],
                "vaga": [None, None, None]}
        self.assertEqual(normaliza_vaga(card), ESTADO_DESCONHECIDA)
        self.assertEqual(card["sl"], [0, 0])
        self.assertFalse(pode_testar_impeto(card))
        self.assertFalse(pode_publicar_resultado(card))

    def test_sl_antigo_sozinho_nao_e_prova(self):
        card = {"sl": [0, 1]}
        self.assertEqual(normaliza_vaga(card), ESTADO_DESCONHECIDA)
        self.assertFalse(pode_testar_impeto(card))
        self.assertFalse(pode_publicar_resultado(card))

    def test_fila_separa_desconhecida_sem_parar_confirmadas(self):
        fila = [
            {"card_id": "livre", "funcao": "A"},
            {"card_id": "sem", "funcao": "B"},
            {"card_id": "desconhecida", "funcao": "C"},
            {"card_id": "ausente", "funcao": "D"},
        ]
        cards = {
            "livre": {"vaga": ["VAGA", None, None]},
            "sem": {"vaga_estado": "confirmada_sem_vaga"},
            "desconhecida": {"vaga": [None, None, None]},
        }
        executaveis, bloqueadas = separa_fila_por_confirmacao(fila, cards)
        self.assertEqual([x["card_id"] for x in executaveis], ["livre", "sem"])
        self.assertEqual([x["card_id"] for x in bloqueadas],
                         ["desconhecida", "ausente"])
        self.assertTrue(all(x["executar_agora"] is False for x in bloqueadas))


if __name__ == "__main__":
    unittest.main()
