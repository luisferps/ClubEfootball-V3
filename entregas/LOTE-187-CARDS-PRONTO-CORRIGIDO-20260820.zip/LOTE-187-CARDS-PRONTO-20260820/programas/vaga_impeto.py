# -*- coding: utf-8 -*-
"""Regra unica e conservadora para a vaga de impeto.

Ausencia de booster, ``sl=[0, 1]`` vindo de fonte antiga e resposta vazia de
uma API NAO provam vaga livre. O motor so pode testar um impeto hipotetico
quando uma fonte especifica marcou ``VAGA`` ou quando existe uma confirmacao
manual rastreavel.

Uma vaga desconhecida tambem nao e um resultado final valido. Ela fica
fechada para o calculo e e separada da fila ate a coleta confirmar se existe
ou nao uma vaga. Assim, ausencia de informacao nunca vira ficha definitiva.
"""

import datetime
import json

ESTADO_LIVRE = "confirmada_livre"
ESTADO_SEM_VAGA = "confirmada_sem_vaga"
ESTADO_DESCONHECIDA = "desconhecida"


def _lista_vaga(card):
    valor = card.get("vaga")
    if isinstance(valor, dict):
        valor = valor.get("v")
    return list(valor) if isinstance(valor, (list, tuple)) else []


def _marcador(valor):
    return str(valor or "").strip().upper()


def estado_da_vaga(card):
    """Devolve o estado comprovavel sem inferir pela ausencia de booster."""
    estado = str(card.get("vaga_estado") or "").strip().lower()
    if estado in (ESTADO_LIVRE, "livre", "vaga_livre", "confirmada livre"):
        return ESTADO_LIVRE
    if estado in (ESTADO_SEM_VAGA, "sem_vaga", "sem vaga", "confirmada sem vaga"):
        return ESTADO_SEM_VAGA

    # Campo novo e explicito: ele nunca e deduzido a partir de `sl`.
    if card.get("vaga_livre_confirmada") is True:
        return ESTADO_LIVRE

    vagas = _lista_vaga(card)
    marcadores = [_marcador(x) for x in vagas if x is not None]
    if "VAGA" in marcadores:
        return ESTADO_LIVRE
    if marcadores:
        # NATIVO/ZERADO? sao respostas do coletor. Se nenhuma posicao e VAGA,
        # nao ha autorizacao para o motor inventar candidato.
        return ESTADO_SEM_VAGA

    situacao = str(card.get("impeto_situacao") or "").lower()
    if "conferid" in situacao and ("vaga vazia" in situacao or "vaga livre" in situacao):
        return ESTADO_LIVRE

    if card.get("vaga_confirmada") is True:
        # Confirmacao explicita sem indicacao de vaga livre significa sem vaga.
        return ESTADO_SEM_VAGA
    return ESTADO_DESCONHECIDA


def normaliza_vaga(card):
    """Aplica a regra segura no card e devolve o estado final.

    ``sl`` continua existindo por compatibilidade com o motor, mas deixa de ser
    uma fonte. Ele passa a ser somente o resultado da confirmacao.
    """
    estado = estado_da_vaga(card)
    livre = estado == ESTADO_LIVRE
    card["sl"] = [0, 1] if livre else [0, 0]
    card["vaga_estado"] = estado
    card["vaga_confirmada"] = estado != ESTADO_DESCONHECIDA
    card["vaga_livre_confirmada"] = livre
    card["vagas_livres"] = 1 if livre else 0
    return estado


def pode_testar_impeto(card):
    """Defesa final do motor: so uma vaga livre confirmada abre candidatos."""
    return estado_da_vaga(card) == ESTADO_LIVRE


def pode_publicar_resultado(card):
    """Somente estados confirmados podem virar resultado definitivo."""
    return estado_da_vaga(card) in (ESTADO_LIVRE, ESTADO_SEM_VAGA)


def separa_fila_por_confirmacao(fila, cards_por_id):
    """Separa linhas executaveis das que ainda exigem coleta da vaga.

    ``cards_por_id`` usa o id-base como chave. Card ausente da fonte e tratado
    como desconhecido e, portanto, tambem fica bloqueado.
    """
    executaveis = []
    bloqueadas = []
    for linha in fila or []:
        card_id = str(linha.get("card_id") or linha.get("id") or "").split("@")[0]
        card = cards_por_id.get(card_id)
        if card is None:
            estado = ESTADO_DESCONHECIDA
        else:
            estado = normaliza_vaga(card)
        if estado in (ESTADO_LIVRE, ESTADO_SEM_VAGA):
            executaveis.append(linha)
            continue
        bloqueada = dict(linha)
        bloqueada.update({
            "card_id": card_id,
            "nome": linha.get("nome") or (card or {}).get("nome"),
            "box": linha.get("box") or (card or {}).get("box"),
            "vaga_estado": estado,
            "classificacao": "BLOQUEADO_RECOLETA_VAGA",
            "motivo": ("card ausente da fonte unica" if card is None else
                       "estado da vaga desconhecido; exige recoleta e confirmacao"),
            "executar_agora": False,
        })
        bloqueadas.append(bloqueada)
    return executaveis, bloqueadas


def grava_relatorio_bloqueados(bloqueadas,
                               caminho_json="fila_RECOLETA_VAGA.json",
                               caminho_txt=None):
    """Materializa o aviso ao operador sem executar nem publicar nada."""
    bloqueadas = list(bloqueadas or [])
    cards = {}
    for linha in bloqueadas:
        card_id = str(linha.get("card_id") or "").split("@")[0]
        item = cards.setdefault(card_id, {
            "card_id": card_id,
            "nome": linha.get("nome"),
            "box": linha.get("box"),
            "vaga_estado": linha.get("vaga_estado") or ESTADO_DESCONHECIDA,
            "linhas": 0,
        })
        item["linhas"] += 1
    payload = {
        "gerado_em": datetime.datetime.now().isoformat(timespec="seconds"),
        "executar_automaticamente": False,
        "seguranca": "nao roda motor, nao publica tela e nao escreve no Supabase",
        "motivo": "vaga desconhecida; exige recoleta e confirmacao",
        "cards_unicos": len(cards),
        "linhas_card_funcao": len(bloqueadas),
        "cards": sorted(cards.values(), key=lambda x: (x.get("nome") or "", x["card_id"])),
        "fila": bloqueadas,
    }
    with open(caminho_json, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    if caminho_txt:
        with open(caminho_txt, "w", encoding="utf-8") as f:
            f.write("CARDS BLOQUEADOS — EXIGEM RECOLETA DA VAGA\n")
            f.write("==========================================\n\n")
            f.write("Nao rodar, nao enviar ao banco e nao mostrar como ficha definitiva.\n")
            f.write("Cards: %d | linhas card x funcao: %d\n\n" %
                    (len(cards), len(bloqueadas)))
            for item in payload["cards"]:
                f.write("%s | %s | %s | %d linhas\n" %
                        (item["card_id"], item.get("nome") or "—",
                         item.get("box") or "—", item["linhas"]))
    return payload
