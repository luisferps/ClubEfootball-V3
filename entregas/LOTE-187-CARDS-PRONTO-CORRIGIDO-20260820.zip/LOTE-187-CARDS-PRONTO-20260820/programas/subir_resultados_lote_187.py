# -*- coding: utf-8 -*-
"""Envia ao Supabase somente as 775 linhas do lote ja validado."""
import json
import os
import sys


CASA = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(CASA)
sys.path.insert(0, os.path.join(CASA, "programas"))

import grava_direto as gd
from vaga_impeto import separa_fila_por_confirmacao


def chave(x):
    return "%s|%s" % (str(x.get("card_id", "")).split("@")[0], x.get("funcao", ""))


fila_total = json.load(open("fila_v6.json", encoding="utf-8"))
base = json.load(open(os.path.join("dados", "base_unica.json"), encoding="utf-8"))
cards = {str(c.get("id", "")).split("@")[0]: c for c in (base.get("cards") or [])}
fila, bloqueadas = separa_fila_por_confirmacao(fila_total, cards)
esperadas = {chave(x) for x in fila}
bloqueadas_chaves = {chave(x) for x in bloqueadas}
por_chave = {}
with open(os.path.join("saida_v6", "linhas.jsonl"), encoding="utf-8") as f:
    for linha in f:
        if linha.strip():
            x = json.loads(linha)
            por_chave[chave(x)] = x

fora_do_lote = set(por_chave) - esperadas - bloqueadas_chaves
faltantes = esperadas - set(por_chave)
if fora_do_lote or faltantes:
    raise SystemExit("PAREI: a saida nao corresponde exatamente a fila confirmada.")

gd.LIGADO = True
ok = 0
falhas = []
for numero, k in enumerate(sorted(esperadas), 1):
    linha = gd._linha(por_chave[k], 6, "v6")
    subiu, erro = gd._manda([linha])
    if subiu:
        ok += 1
    else:
        falhas.append((k, erro))
    if numero % 25 == 0 or numero == len(esperadas):
        print("enviadas ................... %d / %d" %
              (numero, len(esperadas)), flush=True)

if falhas:
    with open("RESULTADOS-QUE-NAO-SUBIRAM.txt", "w", encoding="utf-8") as f:
        for k, erro in falhas:
            f.write("%s | %s\n" % (k, erro))
    print("\nPAREI: %d linhas nao subiram; %d subiram." % (len(falhas), ok))
    print("A lista ficou em RESULTADOS-QUE-NAO-SUBIRAM.txt.")
    raise SystemExit(1)

try:
    os.remove("RESULTADOS-QUE-NAO-SUBIRAM.txt")
except OSError:
    pass
print("\n%d resultados confirmados gravados no banco." % len(esperadas))
