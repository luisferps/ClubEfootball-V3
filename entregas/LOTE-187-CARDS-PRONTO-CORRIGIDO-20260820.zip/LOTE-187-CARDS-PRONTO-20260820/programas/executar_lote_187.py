# -*- coding: utf-8 -*-
"""Executa somente o lote excepcional de 187 cards, com validacao antes do banco."""
import json
import os
import subprocess
import sys
import time


CASA = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(CASA)
sys.path.insert(0, os.path.join(CASA, "programas"))

from vaga_impeto import (grava_relatorio_bloqueados,
                         separa_fila_por_confirmacao)

FILA = "fila_v6.json"
LINHAS = os.path.join("saida_v6", "linhas.jsonl")
PARAR = "PARAR.txt"
BASE = os.path.join("dados", "base_unica.json")
CONFIRMACOES = os.path.join("programas", "vagas_confirmadas.json")


def chave(x):
    return "%s|%s" % (str(x.get("card_id", "")).split("@")[0], x.get("funcao", ""))


def ler_json(caminho, padrao=None):
    try:
        with open(caminho, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return padrao


def resultados():
    por_chave = {}
    erros = []
    if not os.path.exists(LINHAS):
        return por_chave, erros
    with open(LINHAS, encoding="utf-8", errors="replace") as f:
        for numero, linha in enumerate(f, 1):
            linha = linha.strip()
            if not linha:
                continue
            try:
                x = json.loads(linha)
            except Exception as e:
                erros.append("linha %d nao e JSON: %s" % (numero, e))
                continue
            k = chave(x)
            if not k or k == "|":
                erros.append("linha %d sem card ou funcao" % numero)
                continue
            por_chave[k] = x
    return por_chave, erros


def cards_da_base():
    base = ler_json(BASE, {}) or {}
    return {str(c.get("id", "")).split("@")[0]: c
            for c in (base.get("cards") or []) if c.get("id")}


def confere_impetos_confirmados(cards, arquivo_confirmacoes=None):
    """Impede que qualquer fonte automatica altere o que foi fechado no jogo."""
    if arquivo_confirmacoes is None:
        arquivo_confirmacoes = ler_json(CONFIRMACOES, {}) or {}
    confirmados = ((arquivo_confirmacoes.get("impetos_confirmados") or {}).get("cards")
                   if isinstance(arquivo_confirmacoes, dict) else {}) or {}
    erros = []
    for card_id, esperado in confirmados.items():
        card = cards.get(str(card_id))
        if card is None:
            erros.append("%s: card confirmado nao esta na base" % card_id)
            continue
        ids = list(esperado.get("boostIds") or [])
        campos = {
            "boostId": (ids[0] if ids else 0),
            "boostId2": (ids[1] if len(ids) > 1 else 0),
            "nm": [list(x) for x in (esperado.get("nm") or [])],
            "nx": [list(x) for x in (esperado.get("nx") or [])],
            "nmn": list(esperado.get("nmn") or []),
        }
        for campo, valor in campos.items():
            if card.get(campo) != valor:
                erros.append("%s %s: esperado %r, veio %r" %
                             (card_id, campo, valor, card.get(campo)))
    return erros


def remove_resultados_bloqueados(chaves_bloqueadas):
    """Remove somente sobras locais antigas; nunca toca no banco."""
    if not chaves_bloqueadas:
        return
    if os.path.exists(LINHAS):
        temporario = LINHAS + ".confirmadas"
        with open(LINHAS, encoding="utf-8", errors="replace") as origem, \
                open(temporario, "w", encoding="utf-8") as destino:
            for linha in origem:
                try:
                    dado = json.loads(linha)
                except Exception:
                    destino.write(linha)
                    continue
                if chave(dado) not in chaves_bloqueadas:
                    destino.write(linha)
        os.replace(temporario, LINHAS)
    if os.path.exists("feitos.txt"):
        with open("feitos.txt", encoding="utf-8", errors="replace") as f:
            mantidas = [x for x in f if x.strip() not in chaves_bloqueadas]
        with open("feitos.txt", "w", encoding="utf-8") as f:
            f.writelines(mantidas)


def confere_linha(x):
    faltam = []
    if not isinstance(x.get("b1"), (int, float)):
        faltam.append("nota")
    if not isinstance(x.get("vals"), list) or len(x.get("vals") or []) != 26:
        faltam.append("26 atributos")
    if not isinstance(x.get("cadeia"), list) or len(x.get("cadeia") or []) != 26:
        faltam.append("cadeia de 26 atributos")
    barras = x.get("barras")
    chaves_barras = {
        "shooting", "passing", "dribbling", "dexterity",
        "lowerBodyStrength", "aerialStrength", "defending",
        "gk1", "gk2", "gk3",
    }
    if (not isinstance(barras, dict)
            or set(barras) != chaves_barras
            or any(not isinstance(v, (int, float)) for v in barras.values())):
        faltam.append("barras")
    return faltam


def para_motor(proc):
    try:
        with open(PARAR, "w", encoding="utf-8") as f:
            f.write("parar depois do lote validado\n")
        proc.wait(timeout=75)
    except subprocess.TimeoutExpired:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
    finally:
        try:
            os.remove(PARAR)
        except OSError:
            pass


def main():
    print("=" * 68)
    print("  LOTE EXCEPCIONAL - 187 CARDS")
    print("=" * 68)

    obrigatorios = [
        "config.txt", FILA, BASE, CONFIRMACOES,
        os.path.join("dados", "falta_por_card.json"),
        os.path.join("dados", "raras_por_card.json"),
        "CAT_dom.json", "HAB_EFEITOS_FINAL.json", "tecnicos.json",
    ]
    ausentes = [p for p in obrigatorios if not os.path.exists(p)]
    if ausentes:
        print("\nPAREI antes de tocar no banco. Faltam:")
        for p in ausentes:
            print("  - " + p)
        return 1

    fila_total = ler_json(FILA, [])
    todas = {chave(x) for x in fila_total}
    cards_total = {str(x.get("card_id", "")).split("@")[0] for x in fila_total}
    if len(cards_total) != 187 or len(todas) != 775:
        print("\nPAREI antes de tocar no banco.")
        print("A fila deveria ter 187 cards e 775 calculos; veio %d e %d."
              % (len(cards_total), len(todas)))
        return 1

    cards_base = cards_da_base()
    divergencias_manuais = confere_impetos_confirmados(cards_base)
    if divergencias_manuais:
        print("\nPAREI antes de tocar no banco.")
        print("Uma fonte alterou impeto conferido no jogo:")
        for erro in divergencias_manuais[:20]:
            print("  - " + erro)
        return 1

    fila, bloqueadas = separa_fila_por_confirmacao(fila_total, cards_base)
    relatorio = grava_relatorio_bloqueados(bloqueadas)
    esperadas = {chave(x) for x in fila}
    chaves_bloqueadas = {chave(x) for x in bloqueadas}
    cards = {str(x.get("card_id", "")).split("@")[0] for x in fila}
    if (len(cards), len(esperadas), relatorio["cards_unicos"],
            relatorio["linhas_card_funcao"]) != (187, 775, 0, 0):
        print("\nPAREI antes de tocar no banco.")
        print("A separacao segura mudou: executaveis %d/%d; recoleta %d/%d."
              % (len(cards), len(esperadas), relatorio["cards_unicos"],
                 relatorio["linhas_card_funcao"]))
        return 1

    remove_resultados_bloqueados(chaves_bloqueadas)

    # Nesta rodada o motor calcula primeiro no computador. O banco so e tocado
    # depois que as 775 linhas passam pela conferencia estrutural abaixo.
    try:
        os.remove("GRAVA-DIRETO.txt")
    except OSError:
        pass
    try:
        os.remove(PARAR)
    except OSError:
        pass
    if not os.path.exists("fila_EXTRA.json"):
        with open("fila_EXTRA.json", "w", encoding="utf-8") as f:
            json.dump([], f)
    os.makedirs("saida_v6", exist_ok=True)

    prontos, _ = resultados()
    faltam = esperadas - set(prontos)
    print("cards recebidos ........... 187")
    print("cards confirmados ......... %d" % len(cards))
    print("cards para recoleta ....... %d" % relatorio["cards_unicos"])
    print("calculos confirmados ...... %d" % len(esperadas))
    print("ja salvos neste computador  %d" % (len(esperadas) - len(faltam)))

    proc = None
    if faltam:
        print("\nRodando o motor. Pode desligar o computador quando precisar:")
        print("ao abrir este arquivo de novo, ele continua de onde parou.\n")
        proc = subprocess.Popen([sys.executable, os.path.join("programas", "roda_lote_v6.py")])
        ultimo = -1
        while proc.poll() is None:
            prontos, erros_json = resultados()
            feitos = len(esperadas & set(prontos))
            if feitos != ultimo:
                print("concluidos ................. %d / %d" %
                      (feitos, len(esperadas)), flush=True)
                ultimo = feitos
            if erros_json:
                print("\nPAREI: a saida ficou corrompida. Nada foi enviado ao banco.")
                para_motor(proc)
                return 1
            if feitos == len(esperadas):
                para_motor(proc)
                break
            time.sleep(3)
        if proc.poll() not in (0, None) and len(esperadas & set(resultados()[0])) < len(esperadas):
            print("\nO motor parou antes do fim. Nada foi enviado ao banco.")
            return 1

    prontos, erros_json = resultados()
    faltantes = sorted(esperadas - set(prontos))
    extras = sorted(set(prontos) - esperadas)
    defeitos = []
    for k in sorted(esperadas & set(prontos)):
        f = confere_linha(prontos[k])
        if f:
            defeitos.append("%s: %s" % (k, ", ".join(f)))

    if erros_json or faltantes or extras or defeitos:
        print("\nPAREI antes de tocar no banco.")
        print("JSON com erro: %d | faltantes: %d | extras: %d | incompletas: %d"
              % (len(erros_json), len(faltantes), len(extras), len(defeitos)))
        return 1

    print("\nCONFERENCIA PASSOU: %d cards e %d calculos confirmados."
          % (len(cards), len(esperadas)))
    print("Agora os resultados validados vao para o banco.\n")
    r = subprocess.call([sys.executable, os.path.join("programas", "subir_resultados_lote_187.py")])
    if r:
        print("\nO envio dos resultados nao terminou. O calculo local esta salvo.")
        return r

    insumos_bonus = os.path.join("dados", "insumos_bonus.json")
    if os.path.exists(insumos_bonus):
        print("\nRodando o motor de bonus...")
        r = subprocess.call([sys.executable, os.path.join("programas", "motor_bonus.py")])
        if r:
            print("\nOs builds subiram, mas o motor de bonus parou. Veja ULTIMA-RODADA-BONUS.txt.")
            return r
    else:
        print("\nOs builds subiram. O bonus nao rodou porque este computador nao tem")
        print("dados\\insumos_bonus.json. Copie esse arquivo do software oficial e")
        print("abra RODAR-SO-O-BONUS.bat; nenhum calculo sera repetido.")

    print("\nPRONTO. %d cards confirmados foram concluidos." % len(cards))
    print("Os outros %d continuam em fila_RECOLETA_VAGA.json." %
          relatorio["cards_unicos"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
