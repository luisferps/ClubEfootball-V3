# Filas de auditoria de vagas — 20/08/2026

Estes arquivos são somente planejamento. Nenhum deles deve ser entregue automaticamente ao motor ou enviado ao Supabase.

## Fila confirmada

`fila-refazer-confirmada-39-builds-15-cards.json` contém 39 builds de 15 cards em que a vaga adicional foi comprovadamente usada sem autorização da fonte. Todos os itens estão com `executar_agora=false`.

## Fila para recoleta

`fila-recoletar-vaga-703-builds-169-cards.json` contém 703 builds de 169 cards cuja fonte armazenada não é suficiente para confirmar a vaga. Todos os itens estão com `executar_agora=false`.

A ordem obrigatória é:

1. recoletar e confirmar a vaga dos 169 cards;
2. separar somente os cards cuja nova coleta negar a vaga;
3. refazer apenas os resultados confirmados como falsos, mediante autorização explícita.

## Relação com o lote de 187 cards

O lote excepcional de 187 cards é uma execução separada e usa a regra oficial corrigida: estado ausente ou desconhecido fica fechado, sem candidato hipotético. As filas desta pasta não fazem parte da entrada do lote.

Depois que o lote de 187 for executado, a auditoria histórica deverá ser repetida excluindo esses 187 cards, para separar o legado dos resultados produzidos pela coleta nova.
