@echo off
cd /d "%~dp0"
echo parar quando terminar o que esta na mao>PARAR.txt
echo.
echo Pedido de parada salvo. O andamento nao sera perdido.
echo.
pause
