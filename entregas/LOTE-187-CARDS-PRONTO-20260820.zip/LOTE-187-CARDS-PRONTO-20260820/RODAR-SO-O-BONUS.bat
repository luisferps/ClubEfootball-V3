@echo off
chcp 65001 > nul
set PYTHONUTF8=1
set PYTHONUNBUFFERED=1
title BONUS DO LOTE EXCEPCIONAL
cd /d "%~dp0"
if not exist "dados\insumos_bonus.json" (
  echo.
  echo PAREI: falta dados\insumos_bonus.json.
  echo Copie esse arquivo da pasta oficial do software.
  echo.
  pause
  exit /b 1
)
python "programas\motor_bonus.py"
echo.
pause
