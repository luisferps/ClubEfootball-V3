# -*- coding: utf-8 -*-
"""Executa somente o lote excepcional de 187 cards, com validacao antes do banco."""
import json
import os
import subprocess
import sys
import time


CASA = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(CASA)

FILA = "fila_v6.json"
LINHAS = os.path.join("saida_v6", "linhas.jsonl")
PARAR = "PARAR.txt"


def chave(x):
    return "%s|%s" % (str(x.get("card_id", "")).split("@")[0], x.get("funcao", ""))


def ler_json(caminho, padrao=None):
    try:
        with open(caminho, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return padrao


def resultados():
    por_chave = {}
    erros = []
    if not os.path.exists(LINHAS):
        return por_chave, erros
    with open(LINHAS, encoding="utf-8", errors="replace") as f:
        for numero, linha in enumerate(f, 1):
            linha = linha.strip()
            if not linha:
                continue
            try:
                x = json.loads(linha)
            except Exception as e:
                erros.append("linha %d nao e JSON: %s" % (numero, e))
                continue
            k = chave(x)
            if not k or k == "|":
                erros.append("linha %d sem card ou funcao" % numero)
                continue
            por_chave[k] = x
    return por_chave, erros


def confere_linha(x):
    faltam = []
    if not isinstance(x.get("b1"), (int, float)):
        faltam.append("nota")
    if not isinstance(x.get("vals"), list) or len(x.get("vals") or []) != 26:
        faltam.append("26 atributos")
    if not isinstance(x.get("cadeia"), list) or len(x.get("cadeia") or []) != 26:
        faltam.append("cadeia de 26 atributos")
    if not isinstance(x.get("barras"), list):
        faltam.append("barras")
    return faltam


def para_motor(proc):
    try:
        with open(PARAR, "w", encoding="utf-8") as f:
            f.write("parar depois do lote validado\n")
        proc.wait(timeout=75)
    except subprocess.TimeoutExpired:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
    finally:
        try:
            os.remove(PARAR)
        except OSError:
            pass


def main():
    print("=" * 68)
    print("  LOTE EXCEPCIONAL - 187 CARDS")
    print("=" * 68)

    obrigatorios = [
        "config.txt", FILA, os.path.join("dados", "base_unica.json"),
        os.path.join("dados", "falta_por_card.json"),
        os.path.join("dados", "raras_por_card.json"),
        "CAT_dom.json", "HAB_EFEITOS_FINAL.json", "tecnicos.json",
    ]
    ausentes = [p for p in obrigatorios if not os.path.exists(p)]
    if ausentes:
        print("\nPAREI antes de tocar no banco. Faltam:")
        for p in ausentes:
            print("  - " + p)
        return 1

    fila = ler_json(FILA, [])
    esperadas = {chave(x) for x in fila}
    cards = {str(x.get("card_id", "")).split("@")[0] for x in fila}
    if len(cards) != 187 or len(esperadas) != 775:
        print("\nPAREI antes de tocar no banco.")
        print("A fila deveria ter 187 cards e 775 calculos; veio %d e %d."
              % (len(cards), len(esperadas)))
        return 1

    # Nesta rodada o motor calcula primeiro no computador. O banco so e tocado
    # depois que as 775 linhas passam pela conferencia estrutural abaixo.
    try:
        os.remove("GRAVA-DIRETO.txt")
    except OSError:
        pass
    try:
        os.remove(PARAR)
    except OSError:
        pass
    if not os.path.exists("fila_EXTRA.json"):
        with open("fila_EXTRA.json", "w", encoding="utf-8") as f:
            json.dump([], f)
    os.makedirs("saida_v6", exist_ok=True)

    prontos, _ = resultados()
    faltam = esperadas - set(prontos)
    print("cards do lote ............ 187")
    print("calculos esperados ........ 775")
    print("ja salvos neste computador  %d" % (len(esperadas) - len(faltam)))

    proc = None
    if faltam:
        print("\nRodando o motor. Pode desligar o computador quando precisar:")
        print("ao abrir este arquivo de novo, ele continua de onde parou.\n")
        proc = subprocess.Popen([sys.executable, os.path.join("programas", "roda_lote_v6.py")])
        ultimo = -1
        while proc.poll() is None:
            prontos, erros_json = resultados()
            feitos = len(esperadas & set(prontos))
            if feitos != ultimo:
                print("concluidos ................. %d / 775" % feitos, flush=True)
                ultimo = feitos
            if erros_json:
                print("\nPAREI: a saida ficou corrompida. Nada foi enviado ao banco.")
                para_motor(proc)
                return 1
            if feitos == len(esperadas):
                para_motor(proc)
                break
            time.sleep(3)
        if proc.poll() not in (0, None) and len(esperadas & set(resultados()[0])) < len(esperadas):
            print("\nO motor parou antes do fim. Nada foi enviado ao banco.")
            return 1

    prontos, erros_json = resultados()
    faltantes = sorted(esperadas - set(prontos))
    extras = sorted(set(prontos) - esperadas)
    defeitos = []
    for k in sorted(esperadas & set(prontos)):
        f = confere_linha(prontos[k])
        if f:
            defeitos.append("%s: %s" % (k, ", ".join(f)))

    if erros_json or faltantes or extras or defeitos:
        print("\nPAREI antes de tocar no banco.")
        print("JSON com erro: %d | faltantes: %d | extras: %d | incompletas: %d"
              % (len(erros_json), len(faltantes), len(extras), len(defeitos)))
        return 1

    print("\nCONFERENCIA PASSOU: 187 cards e 775 calculos completos.")
    print("Agora os resultados validados vao para o banco.\n")
    r = subprocess.call([sys.executable, os.path.join("programas", "subir_resultados_lote_187.py")])
    if r:
        print("\nO envio dos resultados nao terminou. O calculo local esta salvo.")
        return r

    insumos_bonus = os.path.join("dados", "insumos_bonus.json")
    if os.path.exists(insumos_bonus):
        print("\nRodando o motor de bonus...")
        r = subprocess.call([sys.executable, os.path.join("programas", "motor_bonus.py")])
        if r:
            print("\nOs builds subiram, mas o motor de bonus parou. Veja ULTIMA-RODADA-BONUS.txt.")
            return r
    else:
        print("\nOs builds subiram. O bonus nao rodou porque este computador nao tem")
        print("dados\\insumos_bonus.json. Copie esse arquivo do software oficial e")
        print("abra RODAR-SO-O-BONUS.bat; nenhum calculo sera repetido.")

    print("\nPRONTO. O lote de 187 cards foi concluido e conferido.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
