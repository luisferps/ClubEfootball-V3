# -*- coding: utf-8 -*-
"""Envia ao Supabase somente as 775 linhas do lote ja validado."""
import json
import os
import sys


CASA = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(CASA)
sys.path.insert(0, os.path.join(CASA, "programas"))

import grava_direto as gd


def chave(x):
    return "%s|%s" % (str(x.get("card_id", "")).split("@")[0], x.get("funcao", ""))


fila = json.load(open("fila_v6.json", encoding="utf-8"))
esperadas = {chave(x) for x in fila}
por_chave = {}
with open(os.path.join("saida_v6", "linhas.jsonl"), encoding="utf-8") as f:
    for linha in f:
        if linha.strip():
            x = json.loads(linha)
            por_chave[chave(x)] = x

if set(por_chave) != esperadas:
    raise SystemExit("PAREI: a saida nao corresponde exatamente ao lote validado.")

gd.LIGADO = True
ok = 0
falhas = []
for numero, k in enumerate(sorted(esperadas), 1):
    linha = gd._linha(por_chave[k], 6, "v6")
    subiu, erro = gd._manda([linha])
    if subiu:
        ok += 1
    else:
        falhas.append((k, erro))
    if numero % 25 == 0 or numero == len(esperadas):
        print("enviadas ................... %d / 775" % numero, flush=True)

if falhas:
    with open("RESULTADOS-QUE-NAO-SUBIRAM.txt", "w", encoding="utf-8") as f:
        for k, erro in falhas:
            f.write("%s | %s\n" % (k, erro))
    print("\nPAREI: %d linhas nao subiram; %d subiram." % (len(falhas), ok))
    print("A lista ficou em RESULTADOS-QUE-NAO-SUBIRAM.txt.")
    raise SystemExit(1)

try:
    os.remove("RESULTADOS-QUE-NAO-SUBIRAM.txt")
except OSError:
    pass
print("\n775 resultados gravados no banco.")
