@echo off
chcp 65001 > nul
set PYTHONUTF8=1
set PYTHONUNBUFFERED=1
title LOTE EXCEPCIONAL - 187 CARDS
cd /d "%~dp0"
echo.
echo ============================================================
echo  RODAR SOMENTE AS 23 BOXES / 187 CARDS
echo ============================================================
echo.
python "programas\executar_lote_187.py"
echo.
echo O andamento fica salvo. Se desligar o computador, abra este
echo mesmo arquivo depois e ele continua de onde parou.
echo.
pause
